from __future__ import annotations

import re
import sqlite3
from pathlib import Path

from .util import atomic_write, utc_now

DB_NAME = "vault.db"
SCHEMA = """
CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE entity(id TEXT PRIMARY KEY, kind TEXT, path TEXT, title TEXT);
CREATE TABLE edge(src TEXT, dst TEXT, rel TEXT, PRIMARY KEY(src, dst, rel));
CREATE TABLE segment(
    id INTEGER PRIMARY KEY,
    lesson TEXT,
    start_s REAL,
    heading TEXT,
    text TEXT
);
CREATE VIRTUAL TABLE note_fts USING fts5(lesson UNINDEXED, section, text);
"""

HEADING_RE = re.compile(r"^###\s+(?P<stamp>\d{1,2}:\d{2}(?::\d{2})?)\s+—\s+(?P<title>.+)$")


class IndexError_(RuntimeError):
    pass


def _stamp_seconds(value: str) -> float:
    parts = [int(part) for part in value.split(":")]
    if len(parts) == 3:
        return float(parts[0] * 3600 + parts[1] * 60 + parts[2])
    return float(parts[0] * 60 + parts[1])


def _frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---"):
        return {}
    end = text.find("\n---", 3)
    if end == -1:
        return {}
    fields: dict[str, str] = {}
    for line in text[3:end].splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        fields[key.strip()] = value.strip().strip('"')
    return fields


def _split_sections(body: str) -> list[tuple[str, str, float | None]]:
    sections: list[tuple[str, str, float | None]] = []
    heading = ""
    start: float | None = None
    buffer: list[str] = []

    def flush() -> None:
        if heading or buffer:
            text = "\n".join(buffer).strip()
            if text:
                sections.append((heading or "preamble", text, start))

    for line in body.splitlines():
        if line.startswith("<!-- shellslatee:"):
            continue
        match = HEADING_RE.match(line.strip())
        if match:
            flush()
            heading = match.group("title").strip()
            start = _stamp_seconds(match.group("stamp"))
            buffer = []
            continue
        if line.startswith("## ") or line.startswith("# "):
            flush()
            heading = line.lstrip("# ").strip()
            start = None
            buffer = []
            continue
        stripped = line.strip()
        if stripped:
            buffer.append(stripped)
    flush()
    return sections


def build(out_root: Path) -> Path:
    shellslatee_dir = out_root / ".shellslatee"
    shellslatee_dir.mkdir(parents=True, exist_ok=True)
    target = shellslatee_dir / DB_NAME
    staging = shellslatee_dir / (DB_NAME + ".tmp")
    staging.unlink(missing_ok=True)

    connection = sqlite3.connect(staging)
    try:
        connection.executescript(SCHEMA)
        lessons = 0
        concepts = 0
        for path in sorted(out_root.rglob("*.md")):
            relative = path.relative_to(out_root)
            if any(part.startswith((".", "_")) for part in relative.parts):
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            fields = _frontmatter(text)
            note_id = fields.get("id", "les_" + relative.stem)
            title = fields.get("title", relative.stem)
            connection.execute(
                "INSERT INTO entity(id, kind, path, title) VALUES (?, ?, ?, ?)",
                (note_id, "lesson", relative.as_posix(), title),
            )
            lessons += 1

            concept_ids = [
                item.strip()
                for item in fields.get("concepts", "").strip("[]").split(",")
                if item.strip()
            ]
            for concept_id in concept_ids:
                connection.execute(
                    "INSERT OR IGNORE INTO edge(src, dst, rel) VALUES (?, ?, ?)",
                    (note_id, concept_id, "covers"),
                )

            body = text[text.find("\n---", 3) + 4 :] if text.startswith("---") else text
            for section, section_text, start in _split_sections(body):
                connection.execute(
                    "INSERT INTO note_fts(lesson, section, text) VALUES (?, ?, ?)",
                    (note_id, section, section_text),
                )
                if start is not None:
                    connection.execute(
                        "INSERT INTO segment(lesson, start_s, heading, text) VALUES (?, ?, ?, ?)",
                        (note_id, start, section, section_text),
                    )
        connection.execute(
            "INSERT INTO meta(key, value) VALUES ('built_at', ?)", (utc_now(),)
        )
        connection.execute(
            "INSERT INTO meta(key, value) VALUES ('lessons', ?)", (str(lessons),)
        )
        connection.commit()
    finally:
        connection.close()

    staging.replace(target)
    return target


def open_db(out_root: Path) -> sqlite3.Connection:
    path = out_root / ".shellslatee" / DB_NAME
    if not path.is_file():
        raise IndexError_(f"no index at {path} — run: shellslatee index {out_root}")
    connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def _fts_query(text: str) -> str:
    tokens = re.findall(r"\w+", text)
    if not tokens:
        raise IndexError_("empty query")
    return " ".join(f'"{token}"' for token in tokens)


def search(out_root: Path, query: str, limit: int = 10, dedupe: bool = True) -> list[dict[str, str]]:
    connection = open_db(out_root)
    try:
        try:
            rows = connection.execute(
                "SELECT e.path AS path, e.title AS title, "
                "       snippet(note_fts, 2, '[', ']', '…', 12) AS snippet, "
                "       note_fts.section AS section "
                "FROM note_fts JOIN entity e ON e.id = note_fts.lesson "
                "WHERE note_fts MATCH ? ORDER BY rank LIMIT ?",
                (_fts_query(query), limit),
            ).fetchall()
        except sqlite3.OperationalError as exc:
            raise IndexError_(f"bad query: {exc}") from exc
        results: list[dict[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for row in rows:
            item = dict(row)
            key = (str(item.get("path", "")), str(item.get("section", "")))
            if dedupe and key in seen:
                continue
            seen.add(key)
            results.append(item)
        return results
    finally:
        connection.close()


def concept_pages(out_root: Path) -> list[dict[str, str]]:
    connection = open_db(out_root)
    try:
        rows = connection.execute(
            "SELECT src, dst FROM edge WHERE rel = 'covers' ORDER BY dst, src"
        ).fetchall()
        results: list[dict[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for row in rows:
            item = dict(row)
            key = (str(item.get("path", "")), str(item.get("section", "")))
            if dedupe and key in seen:
                continue
            seen.add(key)
            results.append(item)
        return results
    finally:
        connection.close()
